import { Timesheet } from './timesheet';

describe('Timesheet', () => {
  it('should create an instance', () => {
    expect(new Timesheet()).toBeTruthy();
  });
});
